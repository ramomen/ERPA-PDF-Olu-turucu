
            <div id="header" class="flex-container">

<div id="head1">
  <h1 style="font-size: 25px; font-weight: 400;" id="urunbaslik2"></h1>
  <h2 style="font-size: 1em; line-height:0.2; font-weight: bold;" id="urunaltbaslik2" ></h2>
    </div>
<div id="head2"><img src="erpalogo.png" id="headlogo" alt="">
</div>

</div>

<div class="flex-container" id="sayfa">
<div id="ozellik1">



<div class="row">

<h4 style="font-weight: bold; color:#f18612;"> Genel Özellikler    </h4>


<!-- 1.Sayfa Genel Özellikler Başlangıcı -->
                <div>


                <ul class="a">
<li>Ekonomik ve güvenilir</li>
<li><span style="color=red;" id="uruncozunurluk2"> </span>
çözünürlük</li>
<li><span style="color=red;" id="urunsicaklik2"> </span>
geniş sıcaklık aralığına sahip</li>
<li>Pasif Soğutmalı</li>

<li>Android kartlarla uzaktan yönetilebilir.</li>

<li>Sıva üstü ve asansör içi uygulamalarda kullanılmaktadır</li>
<li>Splitt Screen (ekranı bölümlere ayırabilme) özelliğine sahiptir</li>
<li>Paslanmaz Çelik, Alüminyum, DKP kasa seçeneği</li>
<li>800 derece kadar ısıtılarak daha dayanıklı hale getirilen 4 mm kalınlığında tamperli cam</li>
<li>Elektromanyetik parazit etkilerine karşı korumalı</li>
<li>Elektrik kesintisinde otomatik açılma ve kaldığı yerden devam etme özelliği</li>
<li>%80 enerji tasarrufu</li>
<li>Sistemin çalışma ve kapanma zamanlarını ayarlayabilme özelliği
</li>


</ul>


<img id="urunilkresim" src=""  alt="">



     </div>
<!-- 1.Sayfa Genel Özellikler Başlangıcı -->



</div>








</div>

<div id="ozellik2">
<img id="urunikinciresim" src=""  alt="">

<h4 style="font-weight: bold; color:#f18612;"> Tochi    </h4>
<p>Kullanım alanı çok geniş olan Tochi Endüstriyel ürün serilerimiz
ihtiyaca göre farklı boyutlarda
ve özelliklerde konfigüre edilebilir. Yerli üretim, yüksek kalite ve 
düşük maliyeti ile tercih sebebi olan ürünlerimiz; farklı sinyal, çözünürlük,
parlaklık, dokunmatik gibi çoklu seçenekler sunarak müşteriye özel olarak
tasarlanmakta ve üretimi yapılmaktadır.</p>
<h4 style="font-weight: bold; color:#f18612;"> Yüksek kalite & Garanti    </h4>
<p>
Ürünlerimiz 2 yıl malzeme, ,
10 yıl yedek parça teminat garantisi ile hizmete sunulmaktadır.
</p>

</div>




</div>