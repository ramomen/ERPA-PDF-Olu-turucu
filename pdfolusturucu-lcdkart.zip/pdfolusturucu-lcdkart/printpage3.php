
<div id="header" class="flex-container">

<div id="head1"><h1 style="font-size: 25px; font-weight: 400;" id="urunbaslik"></h1>
              <h2 style="font-size: 1em; line-height:0.2; font-weight: bold;" id="urunaltbaslik"></h2>
              </div>
<div id="head2"><img src="erpalogo.png" id="headlogo" alt="">
</div>


</div>


<div class="flex-container" id="sayfa">
<div id="ozellik1">

<h4 style="font-weight: bold; color:#f18612;"> Teknik Özellikler    </h4>
<div class="row">
  <table  class="table">
      <thead>
        <tr>
          <th scope="col"></th>
          <th scope="col"></th>
         
        </tr>
      </thead>
      <tbody>
        <tr>
          <th scope="row">OSD Language</th>
          <td id="urunosd"></td>
          
        </tr>
        <tr>
          <th scope="row">Panel</th>
          <td id="urunpanelteknik"></td>
       
        </tr>
        <tr>
          <th scope="row"> Input Interface</th>
          <td id="uruninputif"></td>
          
        </tr>
        <tr>
          <th scope="row">Output Interface</th>
          <td id="urunoutputif"></td>
          
        </tr>
        <tr>
          <th scope="row">Audio</Audio></th>
          <td id="urunaudio"></td>
          
        </tr>
        <tr>
          <th scope="row">Terminals</th>
          <td id="urunterminals"></td>
          
        </tr>
        <tr>
          <th scope="row">Dressing Filter</th>
          <td id="urundressing"></td>
          
        </tr>
        <tr>
          <th scope="row">Dynamic Compensation</th>
          <td id="urundynamic"></td>
          
        </tr>
        <tr>
          <th scope="row">Reducing</th>
          <td id="urunreducing"></td>
          
        </tr>
        <tr>
          <th scope="row">Key BD</th>
          <td id="urunkeybd"></td>
          
        </tr>
        
        
      </tbody>
    </table>


  <div style="display: flex;">
  <div id="" style="display: none;"> <img id="iconozellik" src="icons/inch.jpg" alt=""></div>

<div id="inch32" style="display: none;"> <img id="iconozellik" src="icons/inch.jpg" alt=""></div>
<div id="tochit" style="display: none;"><img id="iconozellik" src="icons/tochi_t.jpg" alt=""></div>
<div id="voltaj110" style="display: none;"><img id="iconozellik" src="icons/voltaj.jpg" alt=""></div>  
<div id="darbe" style="display:none;"> 
<img id="iconozellik" src="icons/darbe.jpg" alt="">
</div>
<div id="cozunurluk" style="display: none;"><img id="iconozellik" src="icons/cozunurluk.jpg" alt=""></div>  
<div id="data40inch" style="display:none;"> 
<img id="iconozellik" src="icons/40inch.jpg" alt="">
</div>
<div id="data43inch" style="display:none;"> 
<img id="iconozellik" src="icons/43inch.jpg" alt="">
</div>
<div id="data46inch" style="display:none;"> 
<img id="iconozellik" src="icons/46inch.jpg" alt="">
</div>
<div id="data49inch" style="display:none;"> 
<img id="iconozellik" src="icons/49inch.jpg" alt="">
</div>
<div id="data55inch" style="display:none;"> 
<img id="iconozellik" src="icons/55inch.jpg" alt="">
</div>
<div id="data65inch" style="display:none;"> 
<img id="iconozellik" src="icons/65inch.jpg" alt="">
</div>
<div id="data75inch" style="display:none;"> 
<img id="iconozellik" src="icons/75inch.jpg" alt="">
</div>
<div id="data86inch" style="display:none;"> 
<img id="iconozellik" src="icons/86inch.jpg" alt="">
</div>
<div id="data98inch" style="display:none;"> 
<img id="iconozellik" src="icons/98inch.jpg" alt="">
</div>
<div id="endustri" style="display:none;"> 
<img id="iconozellik" src="icons/endustri.jpg" alt="">
</div>
<div id="4kcozunurluk" style="display:none;"> 
<img id="iconozellik" src="icons/4kcozunurluk.jpg" alt="">
</div>

</div>  
    


</div>
</div>
</div>
