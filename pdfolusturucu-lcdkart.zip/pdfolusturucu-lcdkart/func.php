<?php
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    /*
inputOzellik-renk
inputOzellik-cozunurluk
inputOzellik-panel
inputOzellik-power
*/
    function get_data(){
        $datae = array();
        $datae[] = array(

            'title' => $_POST['inputOzellik-title'],
            'subtitle' => $_POST['inputOzellik-subtitle'],

            'renk' => $_POST['inputOzellik-renk'],
            'cozunurluk' => $_POST['inputOzellik-cozunurluk'],
            'panel' => $_POST['inputOzellik-panelbilgi'],
            'aktifalan' => $_POST['inputOzellik-aktifalan'],
            'enboyorani' => $_POST['inputOzellik-enboyorani'],
            'pikselalani' => $_POST['inputOzellik-pikselalani'],
            'yenilemehizi' => $_POST['inputOzellik-yenilemehizi'],
            'parlaklik' => $_POST['inputOzellik-parlaklik'],
            'kontrast' => $_POST['inputOzellik-kontrast'],
            'gorusacisi' => $_POST['inputOzellik-gorusacisi'],
            'sicaklik' => $_POST['inputOzellik-sicaklik'],
            'lambaomru' => $_POST['inputOzellik-lambaomru'],
            'menuislem' => $_POST['inputOzellik-menuislem'],
            'arayuz' => $_POST['inputOzellik-arayuz'],
            'power' => $_POST['inputOzellik-power'],
            'fourk' => $_POST['inputOzellik-fourk'],
            'darbe' => $_POST['inputOzellik-darbe'],
            'voltaj110' => $_POST['inputOzellik-voltaj110'],
            'tochit' => $_POST['inputOzellik-tochit'],
            'osd' => $_POST['inputOzellik-osd'],
            'panelteknik' => $_POST['inputOzellik-panel'],
            'inputif' => $_POST['inputOzellik-inputif'],

            'outputif' => $_POST['inputOzellik-outputif'],
            'audio' => $_POST['inputOzellik-audio'],
            'terminals' => $_POST['inputOzellik-terminals'],
            'power' => $_POST['inputOzellik-power'],
            'dressing' => $_POST['inputOzellik-dressing'],
            'dynamic' => $_POST['inputOzellik-dynamic'],
            'reducing' => $_POST['inputOzellik-reducing'],
            'keybd' => $_POST['inputOzellik-inputif'],





            'uruncizim' => $_POST['inputOzellik-cizimfile'],


            'urunresim' => $_POST['inputOzellik-urunresim'],
            'urunilkresim' => $_POST['inputOzellik-resimilkfile'],
            'urunikinciresim' => $_POST['inputOzellik-resimikincifile'],
);
        return json_encode($datae);
    }
    $name = "urunbilgi";
   $file_name = $name . '.json';
   
   if(file_put_contents(
    "$file_name", get_data())) {
        echo $file_name . ' dosyasi olusturuldu test1';
       header("Location: prepdf.php");
        exit();

    } 
    else {
        echo ' bir seyler ters gitti.';
    }
}


?>
