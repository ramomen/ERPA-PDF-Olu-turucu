<h1>Teknik Özellikler</h1>

<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" >OSD Language</span>
  </div>
  <input type="text" class="form-control" id="inputOzellik-osd" name="inputOzellik-osd"  >
</div>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" >Panel
    
    </span>
  </div>
  <input type="text" class="form-control" id="inputOzellik-panel" name="inputOzellik-panel"  >
</div>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" >Input Interface</span>
  </div>
  <input type="text" class="form-control" id="inputOzellik-inputif" name="inputOzellik-inputif"  >
</div>
  <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" >Output Interface</span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-outputif" name="inputOzellik-outputif"   >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" >Audio Input</span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-audio" name="inputOzellik-audio"  >
    </div>


    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" >Terminals</span>
      </div>
      <input type="textarea" class="form-control" id="inputOzellik-terminals" name="inputOzellik-terminals" >
    </div>
    

    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" > Dressing filter </span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-dressing" name="inputOzellik-dressing" >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" > Dynamic
compensation </span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-dynamic" name="inputOzellik-dynamic" >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" > Reducing
noise  </span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-reducing" name="inputOzellik-reducing" >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" >Key BD</span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-keybd" name="inputOzellik-keybd" >
    </div>
    
</div>
</div>
