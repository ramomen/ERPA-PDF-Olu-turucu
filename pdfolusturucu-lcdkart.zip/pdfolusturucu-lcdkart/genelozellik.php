<div class="input-group mb-3">
              <div class="input-group-prepend">
                <span class="input-group-text" >Başlık</span>
              </div>
              <input type="text" class="form-control" id="inputOzellik-title" name="inputOzellik-title" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
          </div>
          <div class="input-group mb-3">
              <div class="input-group-prepend">
                <span class="input-group-text" >Alt Başlık</span>
              </div>
              <input type="text" class="form-control" id="inputOzellik-subtitle" name="inputOzellik-subtitle" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
          </div>
  <div class="input-group mb-3">
              <div class="input-group-prepend">
                <span class="input-group-text" >Panel</span>
              </div>
              <input type="text" class="form-control" id="inputOzellik-panel" name="inputOzellik-panelbilgi" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
          </div>
              <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" >Çözünürlük</span>
                  </div>
                  <input type="text" class="form-control" id="inputOzellik-cozunurluk" name="inputOzellik-cozunurluk" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
                </div>
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" >Power</span>
                  </div>
                  <input type="text" class="form-control" id="inputOzellik-power" name="inputOzellik-power" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
                </div>
  
  
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" >Aktif Alan</span>
                  </div>
                  <input type="text" class="form-control" id="inputOzellik-aktifalan" name="inputOzellik-aktifalan" >
                </div>
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" >Renk</span>
                  </div>
                  <input type="text" class="form-control" id="inputOzellik-renk" name="inputOzellik-renk" >
                </div>
  
                <!-- burdan -->
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" >En/Boy Oranı</span>
                  </div>
                  <input type="text" class="form-control" id="inputOzellik-enboyorani" name="inputOzellik-enboyorani" >
                </div>
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" >Piksel Alanı</span>
                  </div>
                  <input type="text" class="form-control" id="inputOzellik-pikselalani" name="inputOzellik-pikselalani" >
                </div>
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" >Yenileme Hızı</span>
                  </div>
                  <input type="text" class="form-control" id="inputOzellik-yenilemehizi" name="inputOzellik-yenilemehizi" >
                </div>
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" >Parlaklık</span>
                  </div>
                  <input type="text" class="form-control" id="inputOzellik-parlaklik" name="inputOzellik-parlaklik" >
                </div>
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" >Kontrast Oranı</span>
                  </div>
                  <input type="text" class="form-control" id="inputOzellik-kontrast" name="inputOzellik-kontrast" >
                </div>
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" >Görüş Açısı</span>
                  </div>
                  <input type="text" class="form-control" id="inputOzellik-gorusacisi" name="inputOzellik-gorusacisi" >
                </div>
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" >Çalışma Sıcaklığı</span>
                  </div>
                  <input type="text" class="form-control" id="inputOzellik-sicaklik" name="inputOzellik-sicaklik" >
                </div>
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" >Lamba Ömrü (saat)</span>
                  </div>
                  <input type="text" class="form-control" id="inputOzellik-lambaomru" name="inputOzellik-lambaomru" >
                </div>
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" >Menü işlemi</span>
                  </div>
                  <input type="text" class="form-control" id="inputOzellik-menuislem" name="inputOzellik-menuislem" >
                </div>
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" >Sinyal Arayüzü</span>
                  </div>
                  <input type="text" class="form-control" id="inputOzellik-arayuz" name="inputOzellik-arayuz" >
                </div>
                <div class="input-group mb-3">
                  <img src="help.png" alt="" width="90%">

                  </div>
  
          </div>