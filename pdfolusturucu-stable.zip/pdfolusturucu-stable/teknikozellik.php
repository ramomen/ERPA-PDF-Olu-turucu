<h1>Teknik Özellikler</h1>

<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" >CPU</span>
  </div>
  <input type="text" class="form-control" id="inputOzellik-cpu" name="inputOzellik-cpu" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
</div>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" >Internal Memory
    </span>
  </div>
  <input type="text" class="form-control" id="inputOzellik-intmemory" name="inputOzellik-intmemory" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
</div>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" >Built-in Memory</span>
  </div>
  <input type="text" class="form-control" id="inputOzellik-builtmemory" name="inputOzellik-builtmemory" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
</div>
  <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" >Dahili ROM</span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-dahilirom" name="inputOzellik-dahilirom" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" >Decode Çözünürlük</span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-decodecozunurluk" name="inputOzellik-decodecozunurluk" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
    </div>


    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" >İşletim sistemi</span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-isletimsistemi" name="inputOzellik-isletimsistemi" >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" > Oyun modu </span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-oyunmodu" name="inputOzellik-oyunmodu" >
    </div>

    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" > Ağ Desteği </span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-agdestegi" name="inputOzellik-agdestegi" >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" > Video Oynatıcı </span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-videooynatici" name="inputOzellik-videooynatici" >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" > Görüntü formatı  </span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-goruntuformati" name="inputOzellik-goruntuformati" >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" >USB 2.0 Port</span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-usbport" name="inputOzellik-usbport" >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" > Sistem güncellemesi </span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-sistemguncellemesi" name="inputOzellik-sistemguncellemesi" >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" > GPS</span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-gps" name="inputOzellik-gps" >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" >WIFI, BT</span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-wifibt" name="inputOzellik-wifibt" >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" > Ethernet </span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-enternet" name="inputOzellik-enternet" >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" > SD Kart </span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-sdkart" name="inputOzellik-sdkart" >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" >Sinyal Arayüzü</span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-arayuz" name="inputOzellik-arayuz" >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" >LVDS Çıkışı</span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-lvdscikisi" name="inputOzellik-lvdscikisi" >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" >HDMI Çıkışı</span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-hdmicikisi" name="inputOzellik-hdmicikisi" >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" > Ses ve Video Çıkışı </span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-sesvevideocikisi" name="inputOzellik-sesvevideocikisi" >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" >RTC Gerçek Zaman Saati</span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-rtc" name="inputOzellik-rtc" >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" >Zamanlama Anahtarı </span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-zamanlama" name="inputOzellik-zamanlama" >
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" > Seri Port </span>
      </div>
      <input type="text" class="form-control" id="inputOzellik-seriport" name="inputOzellik-seriport" >
    </div>
</div>
</div>
