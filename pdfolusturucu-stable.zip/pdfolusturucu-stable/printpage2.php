<div id="header" class="flex-container">

<div id="head1"><h1 style="font-size: 25px; font-weight: 400;" id="sayfaisim"></h1>
              <h2 style="font-size: 1em; line-height:0.2; font-weight: bold;" id="sayfasubtitle"></h2>
              </div>
<div id="head2"><img src="erpalogo.png" id="headlogo" alt="">
</div>


</div>


<div class="flex-container" id="sayfa">
<div id="ozellik1">

<h4 style="font-weight: bold; color:#f18612;"> Genel Özellikler    </h4>
<div class="row">
  <table  class="table">
      <thead>
        <tr>
          <th scope="col">Temel Özellikler</th>
          <th scope="col"></th>
         
        </tr>
      </thead>
      <tbody>
        <tr>
          <th scope="row">Panel</th>
          <td id="urunpanel"></td>
          
        </tr>
        <tr>
          <th scope="row">Çözünürlük</th>
          <td id="uruncozunurluk"></td>
       
        </tr>
        <tr>
          <th scope="row">Aktif Alan</th>
          <td id="urunaktifalan"></td>
          
        </tr>
        <tr>
          <th scope="row">En/boy Oranı</th>
          <td id="urunenboyorani"></td>
          
        </tr>
        <tr>
          <th scope="row">Piksel Alanı</th>
          <td id="urunpikselalani"></td>
          
        </tr>
        <tr>
          <th scope="row">Yenileme Hızı</th>
          <td id="urunyenilemehizi"></td>
          
        </tr>
        <tr>
          <th scope="row">Renk</th>
          <td id="urunrenk"></td>
          
        </tr>
        <tr>
          <th scope="row">Parlaklık</th>
          <td id="urunparlaklik"></td>
          
        </tr>
        <tr>
          <th scope="row">Kontrast Oranı</th>
          <td id="urunkontrast"></td>
          
        </tr>
        <tr>
          <th scope="row">Görüş Açısı</th>
          <td id="urungorusacisi"></td>
          
        </tr>
        <tr>
          <th scope="row">Çalışma Sıcaklığı</th>
          <td  id="urunsicaklik"></td>
          
        </tr>
        <tr>
          <th scope="row">Lamba Ömrü (saat)</th>
          <td id="urunlambaomru"></td>
          
        </tr>
        <tr>
          <th scope="row">Menü İşlemi</th>
          <td id="urunmenuislem"></td>
          
        </tr>
        <tr>
          <th scope="row">Sinyal Arayüzü</th>
          <td id="urunarayuz"></td>
          
        </tr>
        <tr>
          <th scope="row">Power</th>
          <td id="urunpower"></td>
          
        </tr>
        
      </tbody>
    </table>
  
    


</div>






</div>

<div id="ozellik2">

<img id="urunresim" src=""  alt="">

</div>
</div>
<br>
<center>
<img id="uruncizim"  width="650px" height="250px" src="" alt="">

</center>
</div>