
<div class="input-group-prepend">
<br>
<br>
<br>
    <div class="input-group-text">
      <input type="checkbox"  id="inputOzellik-fourk" name="inputOzellik-fourk"> 4K Özelliği
    </div>
    <div class="input-group-text">
      <input type="checkbox"  id="inputOzellik-fourk" name="inputOzellik-darbe"> Darbe Dayanıklılık
    </div>
    <div class="input-group-text">
      <input type="checkbox"  id="inputOzellik-fourk" name="inputOzellik-voltaj110"> 110 - 220 Voltaj  
    </div>
    <div class="input-group-text">
      <input type="checkbox"  id="inputOzellik-fourk" name="inputOzellik-tochit"> TOCHI Tasarım
    </div>
  </div>
    <div class="input-group-prepend">

    <div class="input-group-text">
      <input type="checkbox"  id="inputOzellik-fourk" name="inputOzellik-40inch"> 40 Inch
    </div>
    <div class="input-group-text">
      <input type="checkbox"  id="inputOzellik-fourk" name="inputOzellik-43inch"> 43 Inch    </div>
    <div class="input-group-text">
      <input type="checkbox"  id="inputOzellik-fourk" name="inputOzellik-46inch"> 46 Inch  
    </div>
    <div class="input-group-text">
      <input type="checkbox"  id="inputOzellik-fourk" name="inputOzellik-49inch"> 49 Inch
    </div>
    <div class="input-group-text">
    <input type="checkbox"  id="inputOzellik-fourk" name="inputOzellik-55inch"> 55 Inch
  </div>
  
  <div class="input-group-text">
    <input type="checkbox"  id="inputOzellik-fourk" name="inputOzellik-65inch" > 65 Inch
  </div>
  
  <div class="input-group-text">
    <input type="checkbox"  id="inputOzellik-fourk" name="inputOzellik-75inch"> 75 Inch 
  </div>
  
  <div class="input-group-text">
    <input type="checkbox"  id="inputOzellik-fourk" name="inputOzellik-86inch"> 86 Inch
  </div>
  
  <div class="input-group-text">
  <input type="checkbox"  id="inputOzellik-fourk" name="inputOzellik-98inch"> 98 Inch
</div>
    </div>
<div class="input-group-prepend">

<div class="input-group-text">
  <input type="checkbox"  id="inputOzellik-fourk" name="inputOzellik-endustri" > Endüstriyel Standartlarda
</div>

<div class="input-group-text">

  <input type="checkbox"  id="inputOzellik-fourk" name="inputOzellik-4kcozunurluk"> 4K Çözünürlük   

</div>

    
  </div>